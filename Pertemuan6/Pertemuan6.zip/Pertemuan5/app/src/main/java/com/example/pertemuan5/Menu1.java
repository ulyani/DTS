package com.example.pertemuan5;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu1 extends AppCompatActivity {

    Button BtnOK,BtnHijau,BtnKuning;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);

        BtnOK = findViewById(R.id.Btn1);
        BtnHijau = findViewById(R.id.Btn2);
        BtnKuning = findViewById(R.id.Btn3);



    }

    public void Rubah_Warna(View v) {

        BtnOK.setBackgroundColor(Color.RED);

        BtnOK.setText("Berhasil");



    }
    public void Warna_Hijau(View v) {

        BtnHijau.setBackgroundColor(Color.GREEN);

    }
    public void Warna_Kuning(View v) {

        BtnKuning.setBackgroundColor(Color.YELLOW);

    }
}
