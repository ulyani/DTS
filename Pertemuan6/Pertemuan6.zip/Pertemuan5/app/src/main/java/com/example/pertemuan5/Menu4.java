package com.example.pertemuan5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Menu4 extends AppCompatActivity {
    EditText Isi;
    TextView Hasil_akar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.algo1);

        Isi = findViewById(R.id.Isi_Akar);
        Hasil_akar = findViewById(R.id.Hasil);

    }

    public void Hasil_akar2(View v) {
        int angka, x, y;
        angka = Integer.parseInt(Isi.getText().toString()) ;


        x = 1;
        y = x * x;

        while (y != angka) {
            x = x + 1;
            y = x * x;

        }

        Hasil_akar.setText("Hasil Akar Dari :" +x);
    }
}
